# Cinque Terre Pesto - Short Film

Festiwalowy krotkometrazowy film stop-motion. Estetyka: japonski minimalizm
(wabi-sabi, ma/negative space), Wes Anderson kompozycja, Coraline/Isle of Dogs
feel, kinowe transitions, ruchoma kamera, sterylne kadry, naturalne swiatlo.

Postac "Fuzzball" (felt puppet) sama w kuchni Cinque Terre gotuje trofie z pesto.
Zero dialogu. Zero ludzi. Tylko ambient + ciche mruczenie postaci.

## Providers

**Glowny: Veo 3.1 Standard przez fal.ai** - kinowy color grading, native 4K,
najlepsza motion quality, native audio. ~0.40 USD/s.

**Backup/draft: Seedance 2.0 Pro przez fal.ai** - ~0.14 USD/s, dobre do drafta.

**Character refs: Flux 1.1 Pro Ultra przez Replicate** - najwyzsza jakosc obrazu.

## Workflow

```bash
# 1. Setup (raz)
cp .env.example .env
# wklej lokalnie: FAL_KEY, REPLICATE_API_TOKEN, SUPABASE_URL, SUPABASE_SERVICE_KEY
pip install -r requirements.txt

# 2. Character (raz, ~0.20 USD, manualna akceptacja)
python character/gen_character.py

# 3. Draft - Seedance 2.0 Pro (tanszy test, ~25 USD)
python src/generate.py draft
python src/assemble.py draft

# 4. Final - Veo 3.1 Standard (~75 USD za 3 min przy 0.40/s bez retry)
python src/generate.py final
python src/assemble.py final
```

## Budget

- Flux refs: ~0.20 USD (3x Flux 1.1 Pro Ultra)
- Draft Seedance Pro: 18 * 10 * 0.14 = 25.20 USD + retry = ~35 USD
- Final Veo 3.1 Std: 18 * 10 * 0.40 = 72 USD + retry = ~100 USD
- Budget cap: 200 USD w config.yaml

## Reguly

- Kazdy request: reference_image z config.yaml (3 URL per angle)
- Retry: 3 proby, exponential backoff
- YOLO walidacja post-generation: detekcja `person` -> auto-retry z innym seedem
- Deterministic seed per scena (reproducibility)
- Negative prompt w kazdym call
- Audio wylaczony na poziomie modelu - dogrywamy foley w post
- Post: ffmpeg crossfade miedzy scenami dla kinowych transitions

## Estetyka (zaszyta w style_prefix)

- Japonski minimalizm: wabi-sabi, niedoskonalosc, cisza, przestrzen
- Wes Anderson: symetria, centered composition, pastelowa paleta
- Isle of Dogs/Coraline: stop-motion gravitas, tactile realism
- Oswietlenie: kira-kira, soft window light, chiaroscuro
- Kamera: slow dolly, locked tripod, rare smooth gimbal
- Kadr: 2.39:1 anamorphic feel (w 16:9 container)
- Color: desaturated, cool shadows, warm highlights, teal-orange z japonska
  paleta (indigo, off-white, wood, basil green, olive gold)

## Co MUSI sie pojawic

- Fuzzball sam, zawsze
- Cisza jako element artystyczny (pauzy w kazdej scenie)
- Naturalne detale: para, krople, pylki, swiatlo przeciekajace
- Ruchoma kamera w 6-8 scenach (dolly, pull-out, orbit) - wybiorczo
- Kinowe transitions: fade to black, match cut, J-cut audio

## Co NIE moze sie pojawic

- Ludzie, rece, palce, sylwetki, cienie
- Inne stworzenia
- Glos, dialog, narrator
- Muzyka generowana przez AI (dogrywamy post)
- Napisy, watermarki
- Plynna animacja 60fps (ma byc 12fps stop-motion feel)
- Kolorowy disney look (ma byc festiwalowy, nie bajkowy)

Wszystko w `negative_prompt` + YOLO post-check.
