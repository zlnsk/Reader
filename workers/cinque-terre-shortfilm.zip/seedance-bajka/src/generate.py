"""
Batch generowanie scen przez fal.ai.

Draft: Seedance 2.0 Pro (~0.14 USD/s, tani test kompozycji i ruchu)
Final: Veo 3.1 Standard (~0.40 USD/s, kinowy grading, 1080p, native audio)

Usage:
    python src/generate.py draft   # ~25 USD
    python src/generate.py final   # ~75 USD

Features:
- Asynchroniczne generowanie, concurrency limit (default 3)
- YOLO walidacja: detekcja `person` -> auto-retry z innym seedem (max 3 proby)
- Budget cap w config.yaml
- Deterministic seed per scena, shift na retry
- State w output/spend.json, failures w output/failures.jsonl
"""
import os
import sys
import json
import asyncio
import hashlib
from pathlib import Path
from typing import Optional
from dataclasses import dataclass

import yaml
import httpx
import fal_client
import cv2
from dotenv import load_dotenv
from pydantic import BaseModel

load_dotenv()

ROOT = Path(__file__).parent.parent
CONFIG_PATH = ROOT / "config.yaml"
OUTPUT_DIR = ROOT / "output"

# Cost per second (USD) - approx fal.ai pricing Apr 2026
COST_PER_SEC = {
    "draft": 0.14,   # Seedance 2.0 Pro
    "final": 0.40,   # Veo 3.1 Standard
}


class Scene(BaseModel):
    id: str
    angle: str
    prompt: str


@dataclass
class Config:
    budget_cap: float
    aspect_ratio: str
    resolution: dict
    duration: int
    models: dict
    style_prefix: str
    negative_prompt: str
    reference_urls: dict
    scenes: list[Scene]


def load_config() -> Config:
    with open(CONFIG_PATH) as f:
        raw = yaml.safe_load(f)
    return Config(
        budget_cap=raw["budget_cap_usd"],
        aspect_ratio=raw["aspect_ratio"],
        resolution=raw["output_resolution"],
        duration=raw["scene_duration"],
        models=raw["models"],
        style_prefix=raw["style_prefix"],
        negative_prompt=raw["negative_prompt"],
        reference_urls=raw["character"]["reference_urls"],
        scenes=[Scene(**s) for s in raw["scenes"]],
    )


class Budget:
    def __init__(self, cap_usd: float):
        self.cap = cap_usd
        self.file = OUTPUT_DIR / "spend.json"
        self.spent = 0.0
        if self.file.exists():
            self.spent = json.loads(self.file.read_text()).get("spent", 0.0)

    def charge(self, usd: float):
        if self.spent + usd > self.cap:
            raise RuntimeError(
                f"BUDGET CAP EXCEEDED: {self.spent:.2f} + {usd:.2f} > {self.cap}"
            )
        self.spent += usd
        self.file.parent.mkdir(exist_ok=True)
        self.file.write_text(json.dumps({"spent": self.spent}, indent=2))


def scene_seed(scene_id: str, attempt: int = 0) -> int:
    h = hashlib.md5(f"{scene_id}:{attempt}".encode()).hexdigest()
    return int(h[:8], 16)


_yolo_model = None

def has_humans(video_path: Path) -> bool:
    global _yolo_model
    if _yolo_model is None:
        from ultralytics import YOLO
        _yolo_model = YOLO("yolov8n.pt")

    cap = cv2.VideoCapture(str(video_path))
    detected = False
    for _ in range(5):
        ret, frame = cap.read()
        if not ret:
            break
        results = _yolo_model(frame, classes=[0], verbose=False)
        if len(results[0].boxes) > 0:
            max_conf = results[0].boxes.conf.max().item()
            if max_conf > 0.5:
                detected = True
                break
    cap.release()
    return detected


def build_full_prompt(scene: Scene, cfg: Config) -> str:
    return f"{cfg.style_prefix}\n\nSCENE:\n{scene.prompt}"


async def submit_fal(model_id: str, input_params: dict) -> str:
    """Submit to fal.ai, wait for completion, return video URL."""
    handler = await fal_client.submit_async(model_id, arguments=input_params)

    # Stream logs while waiting
    async for event in handler.iter_events(with_logs=True):
        if hasattr(event, "logs") and event.logs:
            for log in event.logs:
                if log.get("message"):
                    pass  # suppress verbose logs

    result = await handler.get()
    # Result shape: {"video": {"url": "..."}}
    if isinstance(result, dict):
        if "video" in result and isinstance(result["video"], dict):
            return result["video"]["url"]
        if "url" in result:
            return result["url"]
    raise RuntimeError(f"Unexpected fal response shape: {result}")


async def generate_scene(
    scene: Scene,
    cfg: Config,
    mode: str,
    budget: Budget,
    sem: asyncio.Semaphore,
) -> tuple[str, Optional[Path], Optional[str]]:
    out_dir = OUTPUT_DIR / f"{mode}s"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{scene.id}.mp4"

    if out_path.exists():
        print(f"[{scene.id}] Already exists, skipping.")
        return scene.id, out_path, None

    async with sem:
        ref_url = cfg.reference_urls.get(scene.angle)
        if not ref_url:
            return scene.id, None, f"No reference URL for angle={scene.angle}"

        full_prompt = build_full_prompt(scene, cfg)
        resolution = cfg.resolution[mode]
        model_id = cfg.models[mode]
        cost = cfg.duration * COST_PER_SEC[mode]

        for attempt in range(3):
            try:
                budget.charge(cost)
                print(f"[{scene.id}] attempt {attempt+1}/3, mode={mode}, "
                      f"model={model_id}, spent=${budget.spent:.2f}")

                seed = scene_seed(scene.id, attempt)

                # Build input - different models have slightly different schemas
                if "veo3.1" in model_id.lower():
                    input_params = {
                        "prompt": full_prompt,
                        "negative_prompt": cfg.negative_prompt,
                        "image_url": ref_url,
                        "duration": str(cfg.duration),
                        "aspect_ratio": cfg.aspect_ratio,
                        "resolution": resolution,
                        "generate_audio": False,
                        "seed": seed,
                    }
                else:
                    # Seedance 2.0 Pro on fal
                    input_params = {
                        "prompt": full_prompt,
                        "negative_prompt": cfg.negative_prompt,
                        "reference_images": [ref_url],
                        "duration": cfg.duration,
                        "resolution": resolution,
                        "aspect_ratio": cfg.aspect_ratio,
                        "generate_audio": False,
                        "seed": seed,
                    }

                video_url = await submit_fal(model_id, input_params)

                async with httpx.AsyncClient(timeout=300.0) as client:
                    r = await client.get(video_url)
                    r.raise_for_status()
                    out_path.write_bytes(r.content)

                print(f"[{scene.id}] Validating with YOLO...")
                if has_humans(out_path):
                    print(f"[{scene.id}] HUMAN DETECTED, retrying...")
                    out_path.unlink()
                    continue

                print(f"[{scene.id}] OK -> {out_path}")
                return scene.id, out_path, None

            except RuntimeError as e:
                if "BUDGET" in str(e):
                    return scene.id, None, str(e)
                raise
            except Exception as e:
                err = f"attempt {attempt+1}: {type(e).__name__}: {e}"
                print(f"[{scene.id}] {err}")
                if attempt == 2:
                    _log_failure(scene.id, err)
                    return scene.id, None, err
                await asyncio.sleep(2 ** attempt)

        return scene.id, None, "All 3 attempts failed (YOLO detected humans)"


def _log_failure(scene_id: str, error: str):
    fpath = OUTPUT_DIR / "failures.jsonl"
    fpath.parent.mkdir(exist_ok=True)
    with open(fpath, "a") as f:
        f.write(json.dumps({"scene": scene_id, "error": error}) + "\n")


async def main(mode: str):
    if mode not in ("draft", "final"):
        sys.exit("Usage: python src/generate.py [draft|final]")

    cfg = load_config()

    if not all(cfg.reference_urls.values()):
        sys.exit("ERROR: character.reference_urls puste. "
                 "Uruchom najpierw: python character/gen_character.py")

    if not os.environ.get("FAL_KEY"):
        sys.exit("ERROR: FAL_KEY not set (edit .env)")

    budget = Budget(cfg.budget_cap)
    max_concurrent = int(os.environ.get("MAX_CONCURRENT", "3"))
    sem = asyncio.Semaphore(max_concurrent)

    total_est = len(cfg.scenes) * cfg.duration * COST_PER_SEC[mode]

    print(f"\n{'='*60}")
    print(f"GENERATING {len(cfg.scenes)} SCENES - mode={mode}")
    print(f"Model: {cfg.models[mode]}")
    print(f"Resolution: {cfg.resolution[mode]}, duration: {cfg.duration}s")
    print(f"Estimated cost: ${total_est:.2f} (bez retry)")
    print(f"Budget cap: ${cfg.budget_cap:.2f}, already spent: ${budget.spent:.2f}")
    print(f"Max concurrent: {max_concurrent}")
    print(f"{'='*60}\n")

    tasks = [generate_scene(s, cfg, mode, budget, sem) for s in cfg.scenes]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    print(f"\n{'='*60}")
    print("RESULTS")
    print(f"{'='*60}")
    ok = 0
    for r in results:
        if isinstance(r, Exception):
            print(f"EXCEPTION: {r}")
        else:
            sid, path, err = r
            if path:
                print(f"OK   {sid} -> {path}")
                ok += 1
            else:
                print(f"FAIL {sid}: {err}")

    print(f"\n{ok}/{len(cfg.scenes)} scenes succeeded")
    print(f"Total spent: ${budget.spent:.2f}")

    if ok == len(cfg.scenes):
        print(f"\nWszystkie sceny gotowe. Uruchom: python src/assemble.py {mode}")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "draft"
    asyncio.run(main(mode))
