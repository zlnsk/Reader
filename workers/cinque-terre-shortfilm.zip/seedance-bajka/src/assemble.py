"""
Montaz scen z kinowymi transitions (crossfade) + audio mix.

Usage:
    python src/assemble.py draft
    python src/assemble.py final  (default)
"""
import sys
import subprocess
import yaml
from pathlib import Path

ROOT = Path(__file__).parent.parent
CONFIG_PATH = ROOT / "config.yaml"
OUTPUT_DIR = ROOT / "output"
ASSETS_DIR = ROOT / "assets"

# Crossfade duration between scenes (seconds)
XFADE_DURATION = 0.5


def run(cmd: list):
    print(f"+ {' '.join(str(c) for c in cmd[:6])}...")
    subprocess.run(cmd, check=True)


def assemble_with_crossfades(scene_files: list[Path], output: Path, scene_dur: int):
    """Build ffmpeg filter_complex with xfade transitions between all scenes."""
    if len(scene_files) == 1:
        # Pojedyncza scena, tylko reencode do 12fps
        run([
            "ffmpeg", "-y", "-i", str(scene_files[0]),
            "-r", "12", "-c:v", "libx264", "-crf", "18",
            "-preset", "slow", "-pix_fmt", "yuv420p", "-an",
            str(output)
        ])
        return

    # Build input args
    inputs = []
    for f in scene_files:
        inputs.extend(["-i", str(f)])

    # Build xfade chain
    # Each scene is scene_dur long. Offset for xfade N = N * (scene_dur - XFADE_DURATION)
    filter_parts = []
    current = "[0:v]"
    for i in range(1, len(scene_files)):
        offset = i * scene_dur - i * XFADE_DURATION
        next_label = f"[v{i}]" if i < len(scene_files) - 1 else "[vout]"
        filter_parts.append(
            f"{current}[{i}:v]xfade=transition=fade:duration={XFADE_DURATION}:"
            f"offset={offset}{next_label}"
        )
        current = next_label

    filter_complex = ";".join(filter_parts)

    cmd = [
        "ffmpeg", "-y",
        *inputs,
        "-filter_complex", filter_complex,
        "-map", "[vout]",
        "-r", "12",                # stop-motion feel
        "-c:v", "libx264",
        "-crf", "18",
        "-preset", "slow",
        "-pix_fmt", "yuv420p",
        str(output)
    ]
    run(cmd)


def assemble(mode: str = "final"):
    if mode not in ("draft", "final"):
        sys.exit("Usage: python src/assemble.py [draft|final]")

    with open(CONFIG_PATH) as f:
        cfg = yaml.safe_load(f)

    scenes_dir = OUTPUT_DIR / f"{mode}s"
    scene_files = []
    for s in cfg["scenes"]:
        p = scenes_dir / f"{s['id']}.mp4"
        if not p.exists():
            print(f"WARNING: missing {p}, skipping")
            continue
        scene_files.append(p)

    if not scene_files:
        sys.exit(f"No scenes found in {scenes_dir}")

    no_audio = OUTPUT_DIR / f"{mode}_movie_noaudio.mp4"
    final = OUTPUT_DIR / f"{mode}_movie.mp4"

    print(f"Assembling {len(scene_files)} scenes with {XFADE_DURATION}s crossfades...")
    assemble_with_crossfades(scene_files, no_audio, cfg["scene_duration"])
    print(f"Concat done: {no_audio}")

    # Dodaj ambient audio jesli jest
    ambient = ASSETS_DIR / "ambient_kitchen.mp3"
    if ambient.exists():
        print(f"Mixing audio: {ambient}")
        run([
            "ffmpeg", "-y",
            "-i", str(no_audio),
            "-stream_loop", "-1",
            "-i", str(ambient),
            "-c:v", "copy",
            "-c:a", "aac",
            "-b:a", "192k",
            "-filter:a", "volume=0.5,afade=t=in:st=0:d=2,afade=t=out:st=175:d=5",
            "-shortest",
            str(final)
        ])
        print(f"Final with audio: {final}")
    else:
        print(f"\nUwaga: brak {ambient}")
        print(f"Wrzuc plik mp3/wav do assets/ambient_kitchen.mp3 dla pelnego audio.")
        import shutil
        shutil.copy(no_audio, final)
        print(f"Final (bez audio): {final}")

    print(f"\nGotowe: {final}")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "final"
    assemble(mode)
