# Cinque Terre Pesto - Festival Short Film

3-minutowy krotkometrazowy film stop-motion w estetyce japonskiego minimalizmu
(wabi-sabi, ma/negative space, Wes Anderson symetria, Coraline/Isle of Dogs feel).

Postac "Fuzzball" (felt puppet) sama w kuchni Cinque Terre gotuje trofie z pesto.
Zero dialogu, kinowe transitions, ruchoma kamera w wybranych scenach.

## Modele

- **Final: Veo 3.1 Standard** (fal.ai) - kinowy color grading, 1080p native, ~0.40 USD/s
- **Draft: Seedance 2.0 Pro** (fal.ai) - ~0.14 USD/s, test przed final
- **Character refs: Flux 1.1 Pro Ultra** (Replicate) - 4MP fotorealistyczne

## Quickstart

```bash
# 1. Setup (raz)
cp .env.example .env
vi .env   # wklej FAL_KEY, REPLICATE_API_TOKEN, SUPABASE_*

pip install -r requirements.txt

# 2. Character (raz, ~0.30 USD, manualna akceptacja)
python character/gen_character.py

# 3. Draft - Seedance 2.0 Pro (~25 USD, ~15 min)
python src/generate.py draft
python src/assemble.py draft
# obejrzyj output/draft_movie.mp4, zaakceptuj lub iteruj

# 4. Final - Veo 3.1 Standard (~75-100 USD z retry, ~30 min)
python src/generate.py final
python src/assemble.py final
# wynik: output/final_movie.mp4
```

## Klucze API - gdzie zdobyc

- **FAL_KEY**: https://fal.ai/dashboard/keys
- **REPLICATE_API_TOKEN**: https://replicate.com/account/api-tokens
- **SUPABASE_***: Dashboard -> Project Settings -> API

## Struktura

```
seedance-bajka/
├── CLAUDE.md              # instrukcje dla Claude Code
├── config.yaml            # 18 scen, style, character, negative prompt
├── .env.example           # template kluczy (skopiuj do .env)
├── requirements.txt
├── character/
│   └── gen_character.py   # Flux 1.1 Pro Ultra -> 3 referencje
├── src/
│   ├── generate.py        # fal.ai batch generation (Veo/Seedance)
│   └── assemble.py        # ffmpeg xfade crossfades + audio
├── output/
│   ├── drafts/
│   ├── finals/
│   ├── draft_movie.mp4
│   ├── final_movie.mp4
│   ├── spend.json         # budget tracking
│   └── failures.jsonl
└── assets/
    └── ambient_kitchen.mp3  # (opcjonalne) ambient audio
```

## Budzet

| Faza | Koszt |
|---|---|
| Flux refs (3 obrazy) | ~0.30 USD |
| Draft (Seedance Pro, 18x10s) | ~25 USD + retry |
| Final (Veo 3.1 Std, 18x10s) | ~72 USD + retry |
| **Cap** | 200 USD (w config.yaml) |

## Uruchomienie z Claude Code

```bash
claude
```

Powiedz: *"Przeczytaj CLAUDE.md i uruchom workflow od character generation."*

## Cinematic transitions

`assemble.py` laczy sceny z 0.5s crossfade (xfade filter). Wynik wymusza 12fps
stop-motion feel. Jesli chcesz dluzsze/krotsze fade, zmien `XFADE_DURATION`
w `src/assemble.py`.

## YOLO post-check

Po kazdej scenie walidacja 5 klatek modelem YOLO v8n. Detekcja klasy `person`
z confidence > 0.5 -> automatyczny retry z nowym seedem. Max 3 proby.

Pierwsze uruchomienie pobierze `yolov8n.pt` (~6 MB) do biezacego katalogu.

## Ambient audio (opcjonalne ale rekomendowane)

Wrzuc `assets/ambient_kitchen.mp3`. Zrodla:
- freesound.org (CC licenses, search "kitchen ambience cozy")
- Epidemic Sound (subscription)
- YouTube Audio Library (free)

Dla ASMR-owej jakosci polecam dogrywac foley per scena w DaVinci Resolve
zamiast jednego ambient - to daje festiwalowy detail.

## Troubleshooting

- **"BUDGET CAP EXCEEDED"** - zwieksz `budget_cap_usd` w config.yaml lub usun `output/spend.json`
- **"character.reference_urls puste"** - uruchom najpierw `python character/gen_character.py`
- **Scena zle wyglada** - usun plik z `output/drafts/` i uruchom ponownie (skrypt skipuje istniejace)
- **YOLO false positives** - podnies prog w `generate.py` z 0.5 na 0.6
- **fal.ai schema error** - sprawdz aktualny schema na `https://fal.ai/models/fal-ai/veo3.1/standard/api` i dostosuj `input_params` w `generate.py`
