"""
Generuje 3 referencyjne obrazy postaci Fuzzball przez Flux 1.1 Pro Ultra.
Po akceptacji uploaduje do Supabase, aktualizuje config.yaml.

Usage:
    python character/gen_character.py
"""
import os
import sys
import yaml
import httpx
import replicate
from pathlib import Path
from dotenv import load_dotenv
from supabase import create_client

load_dotenv()

ROOT = Path(__file__).parent.parent
CONFIG_PATH = ROOT / "config.yaml"
CHAR_DIR = ROOT / "character"

ANGLES = {
    "front": "front view, facing camera directly, symmetrical pose",
    "three_quarter": "three-quarter angle view, 45-degree pose, slightly turned",
    "profile": "pure side profile view, facing camera-left",
}


def build_prompt(char_desc: str, angle_desc: str) -> str:
    return (
        f"Reference sheet photograph for stop-motion animation, museum-quality "
        f"product photography of a handcrafted felt puppet character on clean "
        f"neutral warm-gray seamless paper background, soft north-facing studio "
        f"daylight, sharp focus on entire character, full body visible in frame, "
        f"{angle_desc}. Character description: {char_desc} "
        f"Tactile craft materials visible - wool felt texture, hand-stitching, "
        f"natural fiber imperfections. Japanese wabi-sabi aesthetic. "
        f"Single character alone in frame. Absolutely no human hands, no human "
        f"body parts, no other creatures visible. Clean character sheet for "
        f"animation reference."
    )


def generate_one(angle: str, angle_desc: str, char_desc: str) -> Path:
    print(f"\n[{angle}] Generating with Flux 1.1 Pro Ultra...")
    prompt = build_prompt(char_desc, angle_desc)

    output = replicate.run(
        "black-forest-labs/flux-1.1-pro-ultra",
        input={
            "prompt": prompt,
            "aspect_ratio": "1:1",
            "output_format": "png",
            "safety_tolerance": 2,
            "raw": False,
        },
    )

    url = str(output) if not isinstance(output, list) else str(output[0])

    out_path = CHAR_DIR / f"ref_{angle}.png"
    with httpx.Client() as client:
        r = client.get(url, timeout=120.0)
        r.raise_for_status()
        out_path.write_bytes(r.content)

    print(f"[{angle}] Saved: {out_path}")
    return out_path


def upload_to_supabase(file_path: Path, remote_name: str) -> str:
    url = os.environ["SUPABASE_URL"]
    key = os.environ["SUPABASE_SERVICE_KEY"]
    bucket = os.environ.get("SUPABASE_BUCKET", "seedance-refs")

    sb = create_client(url, key)

    try:
        sb.storage.create_bucket(bucket, options={"public": True})
    except Exception:
        pass

    with open(file_path, "rb") as f:
        sb.storage.from_(bucket).upload(
            remote_name,
            f.read(),
            file_options={
                "content-type": "image/png",
                "upsert": "true",
            },
        )

    public_url = sb.storage.from_(bucket).get_public_url(remote_name)
    return public_url.rstrip("?")


def update_config(urls: dict):
    with open(CONFIG_PATH) as f:
        cfg = yaml.safe_load(f)

    cfg["character"]["reference_urls"] = urls

    with open(CONFIG_PATH, "w") as f:
        yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True, width=100)

    print(f"\nUpdated {CONFIG_PATH} with reference URLs.")


def main():
    if not os.environ.get("REPLICATE_API_TOKEN"):
        sys.exit("ERROR: REPLICATE_API_TOKEN not set (edit .env)")

    with open(CONFIG_PATH) as f:
        cfg = yaml.safe_load(f)
    char_desc = cfg["character"]["description"]

    CHAR_DIR.mkdir(exist_ok=True)

    paths = {}
    for angle, angle_desc in ANGLES.items():
        paths[angle] = generate_one(angle, angle_desc, char_desc)

    print("\n" + "=" * 60)
    print("REFERENCJE POSTACI WYGENEROWANE")
    print("=" * 60)
    for angle, path in paths.items():
        print(f"  {angle}: {path}")
    print()
    print("Obejrzyj je (np. xdg-open character/ref_front.png).")
    print("Akceptujesz i uploadujesz do Supabase? [y/N]")

    if input("> ").strip().lower() != "y":
        print("Przerwane. Uruchom ponownie aby wygenerowac nowe.")
        sys.exit(0)

    if not os.environ.get("SUPABASE_URL"):
        sys.exit("ERROR: SUPABASE_URL not set (edit .env)")

    print("\nUploading to Supabase...")
    urls = {}
    for angle, path in paths.items():
        urls[angle] = upload_to_supabase(path, f"fuzzball_{angle}.png")
        print(f"  {angle}: {urls[angle]}")

    update_config(urls)
    print("\nGotowe. Uruchom: python src/generate.py draft")


if __name__ == "__main__":
    main()
